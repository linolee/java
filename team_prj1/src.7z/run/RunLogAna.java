package run;

import view.LoginView;

public class RunLogAna {

	public static void main(String[] args) {
//		new RunLogAna();
		new LoginView();
	}

}
