package evt;

import java.awt.Dialog;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JTextField;

public class InputLineDialog extends Dialog implements ActionListener {

	private JTextField jtfStart, jtfEnd;

	public InputLineDialog(FileOpenDialog fod) {
		super(fod, "���� �Է�", true);
		jtfStart = new JTextField();
		jtfEnd = new JTextField();
		add(jtfStart);
		add(jtfEnd);
		jtfStart.setBounds(100,	100, 100, 40);
		jtfEnd.setBounds(100, 100, 100, 40);
		
		
		
		setVisible(true);
		setBounds(fod.getX()+50, fod.getY()+50, 300, 100);
		
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub

	}
}
