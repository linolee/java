package evt;

import java.awt.Dialog;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import view.MainControlView;

public class FileOpenDialog extends Dialog implements ActionListener {

	
	
	public FileOpenDialog(MainControlView mcv) {
		super(mcv, "���� ����", true);
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub

	}

}
