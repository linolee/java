package run;

import view.MainControlView;

public class RunLogAnalysis {

	public static void main(String[] args) {
		new MainControlView();
	}

}
